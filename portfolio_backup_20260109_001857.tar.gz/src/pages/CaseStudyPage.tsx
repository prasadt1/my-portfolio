import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
    ArrowLeft,
    CheckCircle2,
    Clock,
    ArrowRight,
    AlertCircle
} from 'lucide-react';
import { caseStudies } from '../data/caseStudies';

const CaseStudyPage: React.FC = () => {
    const { slug } = useParams<{ slug: string }>();

    const study = caseStudies.find(s => s.slug === slug || s.id === slug); // Support both ID and slug lookup

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [slug]);

    if (!study) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <h2 className="text-2xl font-bold mb-4">Case Study Not Found</h2>
                    <Link to="/projects" className="text-emerald-600 hover:underline">Return to Projects</Link>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-white dark:bg-slate-900 pt-20">
            {/* Header */}
            <section className="bg-slate-50 dark:bg-slate-800 pb-16 pt-12 border-b border-slate-200 dark:border-slate-700">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <Link to="/projects" className="inline-flex items-center gap-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 mb-8 transition-colors">
                        <ArrowLeft size={20} />
                        Back to Projects
                    </Link>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="grid lg:grid-cols-2 gap-12 items-center"
                    >
                        <div>
                            <div className="text-emerald-600 dark:text-emerald-400 font-bold tracking-wider text-sm uppercase mb-4">
                                {study.header.eyebrow}
                            </div>
                            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-white mb-6 leading-tight">
                                {study.header.title}
                            </h1>
                            <div className="flex flex-wrap gap-4 text-sm text-slate-600 dark:text-slate-400">
                                <span className="bg-white dark:bg-slate-900 px-3 py-1 rounded-full border border-slate-200 dark:border-slate-700">
                                    {study.header.client.type}
                                </span>
                                <span className="bg-white dark:bg-slate-900 px-3 py-1 rounded-full border border-slate-200 dark:border-slate-700">
                                    {study.header.client.industry}
                                </span>
                                <span className="bg-white dark:bg-slate-900 px-3 py-1 rounded-full border border-slate-200 dark:border-slate-700">
                                    {study.header.client.size}
                                </span>
                            </div>
                        </div>

                        {/* Hero Metric Card */}
                        <div className="bg-emerald-600 text-white rounded-2xl p-8 shadow-2xl relative overflow-hidden">
                            <div className="relative z-10">
                                <div className="text-6xl font-bold mb-2">{study.outcomes.hero_metric.value}</div>
                                <div className="text-emerald-100 text-xl font-medium">{study.outcomes.hero_metric.label}</div>
                                <div className="mt-8 pt-8 border-t border-emerald-500/50 flex gap-8">
                                    {study.outcomes.secondary_metrics.slice(0, 2).map((metric, idx) => (
                                        <div key={idx}>
                                            <div className="text-2xl font-bold">{metric.value}</div>
                                            <div className="text-sm text-emerald-100">{metric.label}</div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            {/* Background decoration */}
                            <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-emerald-500 rounded-full opacity-20 blur-3xl"></div>
                        </div>
                    </motion.div>
                </div>
            </section>

            {/* Challenge Section */}
            <section className="py-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid md:grid-cols-12 gap-12">
                        <div className="md:col-span-4">
                            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-6">The Challenge</h2>
                            <p className="text-slate-600 dark:text-slate-300 leading-relaxed mb-8">
                                {study.challenge.situation}
                            </p>
                            <div className="bg-amber-50 dark:bg-amber-900/20 p-6 rounded-xl border border-amber-200 dark:border-amber-700/50">
                                <div className="text-sm font-bold text-amber-800 dark:text-amber-400 uppercase tracking-wide mb-2">Urgency</div>
                                <p className="text-slate-900 dark:text-white italic">"{study.challenge.urgency}"</p>
                            </div>
                        </div>

                        <div className="md:col-span-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                            {study.challenge.pain_points.map((pain, idx) => (
                                <div key={idx} className="bg-slate-50 dark:bg-slate-800 p-6 rounded-xl border border-slate-100 dark:border-slate-700">
                                    <div className="text-4xl mb-4">{pain.icon}</div>
                                    <h3 className="font-bold text-slate-900 dark:text-white mb-2">{pain.title}</h3>
                                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">{pain.description}</p>
                                    <p className="text-xs font-bold text-red-500 dark:text-red-400 uppercase">Impact: {pain.impact}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            {/* Approach Section */}
            <section className="py-20 bg-slate-50 dark:bg-slate-800">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">
                            The Approach: {study.approach.methodology}
                        </h2>
                        <p className="text-slate-600 dark:text-slate-400">
                            Why me: {study.challenge.why_prasad}
                        </p>
                    </div>

                    <div className="space-y-8 relative">
                        {/* Thread line */}
                        <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-slate-200 dark:bg-slate-700 -z-10 hidden md:block"></div>

                        {study.approach.phases.map((phase, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                className={`flex flex-col md:flex-row gap-8 items-center ${idx % 2 === 0 ? 'md:flex-row-reverse' : ''}`}
                            >
                                <div className="flex-1 w-full">
                                    <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl shadow-lg border border-slate-100 dark:border-slate-700 hover:border-emerald-500 transition-colors">
                                        <div className="flex items-center justify-between mb-4">
                                            <span className="bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400 px-3 py-1 rounded-full text-sm font-bold">
                                                Phase {phase.number}
                                            </span>
                                            <span className="flex items-center gap-2 text-slate-500 dark:text-slate-400 text-sm">
                                                <Clock size={16} /> {phase.duration}
                                            </span>
                                        </div>
                                        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-4">{phase.title}</h3>
                                        <ul className="space-y-2 mb-6">
                                            {phase.activities.map((activity, aIdx) => (
                                                <li key={aIdx} className="flex items-start gap-2 text-sm text-slate-600 dark:text-slate-300">
                                                    <CheckCircle2 size={16} className="text-emerald-500 mt-0.5 flex-shrink-0" />
                                                    {activity}
                                                </li>
                                            ))}
                                        </ul>
                                        <div className="bg-emerald-50 dark:bg-emerald-900/10 p-4 rounded-lg">
                                            <div className="text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase mb-1">Outcome</div>
                                            <div className="text-sm text-slate-900 dark:text-white font-medium">{phase.outcome}</div>
                                        </div>
                                    </div>
                                </div>

                                {/* Number Bubble */}
                                <div className="w-8 h-8 rounded-full bg-emerald-600 border-4 border-white dark:border-slate-800 flex items-center justify-center text-white font-bold z-10 hidden md:flex">
                                    {phase.number}
                                </div>

                                <div className="flex-1 hidden md:block"></div>
                            </motion.div>
                        ))}
                    </div>

                    <div className="mt-16 text-center">
                        <div className="inline-block bg-white dark:bg-slate-900 px-8 py-4 rounded-full border border-slate-200 dark:border-slate-700 shadow-sm">
                            <span className="font-bold text-slate-900 dark:text-white mr-2">Secret Weapon:</span>
                            <span className="text-slate-600 dark:text-slate-400">{study.approach.unique_differentiator}</span>
                        </div>
                    </div>
                </div>
            </section>

            {/* Technical Deep Dive */}
            <section className="py-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-12 text-center">Technical Transformation</h2>

                    <div className="grid md:grid-cols-2 gap-12">
                        {/* Before */}
                        <div className="space-y-6">
                            <h3 className="text-xl font-bold text-slate-500 dark:text-slate-400 flex items-center gap-2">
                                <AlertCircle size={24} /> Before State
                            </h3>
                            <div className="bg-slate-50 dark:bg-slate-800 p-8 rounded-2xl border border-slate-200 dark:border-slate-700">
                                <div className="space-y-4">
                                    <div>
                                        <div className="text-sm font-semibold text-slate-500 uppercase mb-2">Legacy Stack</div>
                                        <div className="flex flex-wrap gap-2">
                                            {study.technical.before.stack.map((t, i) => (
                                                <span key={i} className="px-2 py-1 bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs rounded">
                                                    {t}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                    <div>
                                        <div className="text-sm font-semibold text-slate-500 uppercase mb-2">Issues</div>
                                        <ul className="space-y-2">
                                            {study.technical.before.issues.map((issue, i) => (
                                                <li key={i} className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                                                    <span className="w-1.5 h-1.5 rounded-full bg-red-400"></span> {issue}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* After */}
                        <div className="space-y-6">
                            <h3 className="text-xl font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-2">
                                <CheckCircle2 size={24} /> After State
                            </h3>
                            <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border-2 border-emerald-500/20 shadow-xl">
                                <div className="space-y-4">
                                    <div>
                                        <div className="text-sm font-semibold text-emerald-600/80 uppercase mb-2">Modern Stack</div>
                                        <div className="flex flex-wrap gap-2">
                                            {study.technical.after.stack.map((t, i) => (
                                                <span key={i} className="px-2 py-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300 text-xs font-medium rounded">
                                                    {t}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                    <div>
                                        <div className="text-sm font-semibold text-emerald-600/80 uppercase mb-2">Improvements</div>
                                        <ul className="space-y-2">
                                            {study.technical.after.improvements.map((imp, i) => (
                                                <li key={i} className="flex items-center gap-2 text-sm text-slate-900 dark:text-white font-medium">
                                                    <CheckCircle2 size={14} className="text-emerald-500" /> {imp}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Testimonial */}
            <section className="py-20 bg-emerald-900 text-white relative overflow-hidden">
                <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
                <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
                    <div className="text-6xl text-emerald-500 mb-8 opacity-50 font-serif">"</div>
                    <blockquote className="text-2xl md:text-3xl font-medium leading-relaxed mb-8">
                        {study.testimonial.quote}
                    </blockquote>
                    <cite className="not-italic">
                        <div className="font-bold text-lg">{study.testimonial.author.name}</div>
                        <div className="text-emerald-300">{study.testimonial.author.role}, {study.testimonial.author.company}</div>
                    </cite>
                </div>
            </section>

            {/* CTA */}
            <section className="py-24 bg-white dark:bg-slate-900">
                <div className="max-w-4xl mx-auto px-4 text-center">
                    <h2 className="text-4xl font-bold text-slate-900 dark:text-white mb-6">Want similar results?</h2>
                    <p className="text-xl text-slate-600 dark:text-slate-400 mb-10 max-w-2xl mx-auto">
                        {study.cta.primary.context}
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <a
                            href={study.cta.primary.action}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all shadow-xl hover:shadow-2xl flex items-center justify-center gap-2"
                        >
                            {study.cta.primary.text}
                            <ArrowRight size={20} />
                        </a>
                        <Link
                            to={study.cta.secondary.action}
                            className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-8 py-4 rounded-xl font-bold text-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
                        >
                            {study.cta.secondary.text}
                        </Link>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default CaseStudyPage;
