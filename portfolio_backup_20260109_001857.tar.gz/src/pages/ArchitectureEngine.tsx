import React, { useState } from 'react';
import { Activity, CreditCard, ShoppingCart, Cpu, Loader2, ArrowLeft, AlertTriangle } from 'lucide-react';
import { generateArchitecture } from '../services/architectureGenerator';
import type { ArchitectureRequest, ArchitectureResult } from '../types';
import ArchitectureDiagram from '../components/ArchitectureDiagram';
import SEO from '../components/SEO';

type IndustryType = 'healthcare' | 'financial' | 'ecommerce' | 'aiml';

interface Industry {
  id: IndustryType;
  title: string;
  icon: React.ReactNode;
  compliance: string[];
  color: string;
}

const INDUSTRIES: Industry[] = [
  {
    id: 'healthcare',
    title: 'Healthcare & Pharma',
    icon: <Activity size={32} />,
    compliance: ['HIPAA', 'FHIR', 'HL7', 'GDPR'],
    color: '#3b82f6'
  },
  {
    id: 'financial',
    title: 'Financial Services',
    icon: <CreditCard size={32} />,
    compliance: ['PCI-DSS', 'SOC2', 'KYC', 'AML'],
    color: '#10b981'
  },
  {
    id: 'ecommerce',
    title: 'eCommerce & Retail',
    icon: <ShoppingCart size={32} />,
    compliance: ['PCI-DSS', 'GDPR', 'Multi-tenant'],
    color: '#f97316'
  },
  {
    id: 'aiml',
    title: 'AI & Machine Learning',
    icon: <Cpu size={32} />,
    compliance: ['Ethical AI', 'Data Privacy', 'MLOps'],
    color: '#a855f7'
  }
];

const EXAMPLE_PROMPTS: Record<IndustryType, string> = {
  healthcare: 'Modernize a 20-year-old patient records system while maintaining HIPAA compliance. Budget: $500K, Timeline: 12 months.',
  financial: 'Build real-time payment processing for 1M+ transactions/day. Need PCI-DSS Level 1 compliance.',
  ecommerce: 'Multi-tenant SaaS platform for 50K+ merchants. Need 99.99% uptime and global scalability.',
  aiml: 'Build RAG pipeline for legal document analysis. Process 10TB+ PDFs, serve answers in real-time.'
};

const ArchitectureEngine: React.FC = () => {
  const [step, setStep] = useState<'industry' | 'input' | 'generating' | 'result'>('industry');
  const [selectedIndustry, setSelectedIndustry] = useState<IndustryType | null>(null);
  const [challenge, setChallenge] = useState('');
  const [result, setResult] = useState<ArchitectureResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleIndustrySelect = (industry: IndustryType) => {
    setSelectedIndustry(industry);
    setChallenge(EXAMPLE_PROMPTS[industry]);
    setStep('input');
    setError(null);
  };

  const handleGenerate = async () => {
    if (!selectedIndustry || !challenge) return;

    setStep('generating');
    setError(null);

    try {
      const request: ArchitectureRequest = {
        industry: selectedIndustry,
        challenge,
        context: {}
      };

      const generated = await generateArchitecture(request);

      const architectureResult: ArchitectureResult = {
        ...generated,
        id: Date.now().toString(),
        timestamp: new Date(),
        inputs: {
          industry: selectedIndustry,
          challenge,
          context: {}
        }
      };

      setResult(architectureResult);
      setStep('result');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate architecture');
      setStep('input');
    }
  };

  const handleReset = () => {
    setStep('industry');
    setSelectedIndustry(null);
    setChallenge('');
    setResult(null);
    setError(null);
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '3rem 1.5rem' }}>
      <SEO
        title="AI Architecture Engine"
        description="AI-powered architecture decision engine. Get expert recommendations for cloud, healthcare, financial, and e-commerce systems."
        keywords="architecture engine, AI architecture, system design, cloud architecture"
      />
      {/* Header */}
      <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
        <h1 style={{ fontSize: '2.5rem', marginBottom: '1rem', fontFamily: 'Crimson Text, serif' }}>
          AI-Powered Architecture Decision Engine
        </h1>
        <p style={{ fontSize: '1.125rem', color: '#64748b', maxWidth: '800px', margin: '0 auto' }}>
          Get expert architecture recommendations based on 15+ years of enterprise experience
          across Healthcare, Financial Services, eCommerce, and AI/ML
        </p>
      </div>

      {/* Industry Selection */}
      {step === 'industry' && (
        <div>
          <h2 style={{ fontSize: '1.5rem', textAlign: 'center', marginBottom: '2rem' }}>
            Select Your Industry
          </h2>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: '1.5rem'
            }}
          >
            {INDUSTRIES.map((industry) => (
              <button
                key={industry.id}
                onClick={() => handleIndustrySelect(industry.id)}
                style={{
                  padding: '2rem',
                  backgroundColor: 'white',
                  border: '2px solid #e2e8f0',
                  borderRadius: '1rem',
                  cursor: 'pointer',
                  textAlign: 'left',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = industry.color;
                  e.currentTarget.style.transform = 'translateY(-4px)';
                  e.currentTarget.style.boxShadow = '0 10px 25px rgba(0,0,0,0.1)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = '#e2e8f0';
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                <div style={{ color: industry.color, marginBottom: '1rem' }}>
                  {industry.icon}
                </div>
                <h3 style={{ fontSize: '1.25rem', marginBottom: '0.5rem' }}>
                  {industry.title}
                </h3>
                <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                  {industry.compliance.map((comp) => (
                    <span
                      key={comp}
                      style={{
                        fontSize: '0.75rem',
                        padding: '0.25rem 0.5rem',
                        backgroundColor: '#f1f5f9',
                        borderRadius: '0.25rem',
                        color: '#64748b'
                      }}
                    >
                      {comp}
                    </span>
                  ))}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Challenge Input */}
      {step === 'input' && (
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <button
            onClick={handleReset}
            style={{
              marginBottom: '2rem',
              padding: '0.5rem 1rem',
              backgroundColor: 'transparent',
              border: '1px solid #e2e8f0',
              borderRadius: '0.5rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              color: '#64748b'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = '#16a34a';
              e.currentTarget.style.color = '#16a34a';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = '#e2e8f0';
              e.currentTarget.style.color = '#64748b';
            }}
          >
            <ArrowLeft size={20} />
            Back to Industries
          </button>

          <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>
            Describe Your Challenge
          </h2>

          <textarea
            value={challenge}
            onChange={(e) => setChallenge(e.target.value)}
            placeholder="Describe your technical challenge or system requirements..."
            style={{
              width: '100%',
              minHeight: '150px',
              padding: '1rem',
              fontSize: '1rem',
              border: '2px solid #e2e8f0',
              borderRadius: '0.5rem',
              marginBottom: '1.5rem',
              fontFamily: 'inherit',
              resize: 'vertical'
            }}
          />

          {error && (
            <div
              style={{
                padding: '1rem',
                backgroundColor: '#fef2f2',
                border: '1px solid #fecaca',
                borderRadius: '0.5rem',
                color: '#dc2626',
                marginBottom: '1rem',
                display: 'flex',
                alignItems: 'start',
                gap: '0.75rem'
              }}
            >
              <AlertTriangle size={20} style={{ flexShrink: 0, marginTop: '0.125rem' }} />
              <div>{error}</div>
            </div>
          )}

          <button
            onClick={handleGenerate}
            disabled={!challenge}
            style={{
              width: '100%',
              padding: '1rem',
              backgroundColor: challenge ? '#16a34a' : '#94a3b8',
              color: 'white',
              border: 'none',
              borderRadius: '0.5rem',
              fontSize: '1rem',
              fontWeight: 600,
              cursor: challenge ? 'pointer' : 'not-allowed',
              transition: 'background-color 0.2s ease'
            }}
            onMouseEnter={(e) => {
              if (challenge) {
                e.currentTarget.style.backgroundColor = '#15803d';
              }
            }}
            onMouseLeave={(e) => {
              if (challenge) {
                e.currentTarget.style.backgroundColor = '#16a34a';
              }
            }}
          >
            Generate Architecture
          </button>
        </div>
      )}

      {/* Generating */}
      {step === 'generating' && (
        <div style={{ textAlign: 'center', padding: '4rem 0' }}>
          <Loader2
            size={48}
            className="animate-spin"
            style={{ color: '#16a34a', margin: '0 auto' }}
          />
          <p style={{ marginTop: '1rem', fontSize: '1.125rem', color: '#64748b' }}>
            AI is analyzing your requirements...
          </p>
          <p style={{ marginTop: '0.5rem', fontSize: '0.875rem', color: '#94a3b8' }}>
            This may take 10-20 seconds
          </p>
        </div>
      )}

      {/* Results */}
      {step === 'result' && result && (
        <div>
          <button
            onClick={handleReset}
            style={{
              marginBottom: '2rem',
              padding: '0.5rem 1rem',
              backgroundColor: 'transparent',
              border: '1px solid #e2e8f0',
              borderRadius: '0.5rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              color: '#64748b'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = '#16a34a';
              e.currentTarget.style.color = '#16a34a';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = '#e2e8f0';
              e.currentTarget.style.color = '#64748b';
            }}
          >
            <ArrowLeft size={20} />
            Start New Analysis
          </button>

          <div style={{ display: 'grid', gap: '2rem' }}>
            {/* Executive Summary */}
            <div style={{ padding: '2rem', backgroundColor: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0' }}>
              <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Executive Summary</h2>
              <p style={{ lineHeight: 1.6, color: '#475569', fontSize: '1.0625rem' }}>{result.summary}</p>
            </div>

            {/* Recommendations */}
            <div style={{ padding: '2rem', backgroundColor: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0' }}>
              <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Key Recommendations</h2>
              <ul style={{ paddingLeft: '1.5rem', lineHeight: 1.8, color: '#475569' }}>
                {result.recommendations.map((rec, idx) => (
                  <li key={idx} style={{ marginBottom: '0.75rem' }}>{rec}</li>
                ))}
              </ul>
            </div>

            {/* Timeline & Budget */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1.5rem' }}>
              <div style={{ padding: '1.5rem', backgroundColor: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0' }}>
                <h3 style={{ fontSize: '0.875rem', marginBottom: '0.5rem', color: '#64748b', textTransform: 'uppercase', fontWeight: 600, letterSpacing: '0.05em' }}>Timeline</h3>
                <p style={{ fontSize: '1.75rem', color: '#16a34a', fontWeight: 700 }}>{result.timeline}</p>
              </div>
              <div style={{ padding: '1.5rem', backgroundColor: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0' }}>
                <h3 style={{ fontSize: '0.875rem', marginBottom: '0.5rem', color: '#64748b', textTransform: 'uppercase', fontWeight: 600, letterSpacing: '0.05em' }}>Budget</h3>
                <p style={{ fontSize: '1.75rem', color: '#16a34a', fontWeight: 700 }}>{result.budget}</p>
              </div>
            </div>

            {/* Interactive Architecture Diagram */}
            <div style={{ padding: '2rem', backgroundColor: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0' }}>
              <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Architecture Diagram</h2>
              <p style={{ fontSize: '0.9375rem', color: '#64748b', marginBottom: '1rem' }}>
                Interactive diagram showing {result.diagram.nodes.length} components. Click nodes to see details. Use controls to zoom and pan.
              </p>
              <div style={{
                height: '600px',
                marginBottom: '1.5rem',
                border: '1px solid #e2e8f0',
                borderRadius: '0.75rem',
                overflow: 'hidden'
              }}>
                <ArchitectureDiagram
                  nodes={result.diagram.nodes}
                  edges={result.diagram.edges}
                />
              </div>

              {/* Component Details (Collapsible) */}
              <details style={{ marginTop: '1.5rem' }}>
                <summary style={{
                  cursor: 'pointer',
                  fontWeight: 600,
                  padding: '0.75rem 1rem',
                  backgroundColor: '#f8fafc',
                  borderRadius: '0.5rem',
                  border: '1px solid #e2e8f0',
                  userSelect: 'none'
                }}>
                  View Component Details ({result.diagram.nodes.length} components)
                </summary>
                <div style={{ display: 'grid', gap: '1rem', marginTop: '1rem' }}>
                  {result.diagram.nodes.map((node) => (
                    <div
                      key={node.id}
                      style={{
                        padding: '1.25rem',
                        backgroundColor: '#f8fafc',
                        borderRadius: '0.75rem',
                        border: '1px solid #e2e8f0'
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem' }}>
                        <span
                          style={{
                            padding: '0.375rem 0.75rem',
                            backgroundColor: '#0f172a',
                            color: 'white',
                            borderRadius: '0.375rem',
                            fontSize: '0.75rem',
                            fontWeight: 600,
                            textTransform: 'uppercase'
                          }}
                        >
                          {node.type}
                        </span>
                        <h3 style={{ fontSize: '1.125rem', fontWeight: 600 }}>{node.label}</h3>
                      </div>
                      <p style={{ color: '#64748b', marginBottom: '0.75rem', lineHeight: 1.6 }}>
                        {node.description}
                      </p>
                      {node.technologies.length > 0 && (
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                          {node.technologies.map((tech, idx) => (
                            <span
                              key={idx}
                              style={{
                                padding: '0.25rem 0.625rem',
                                backgroundColor: 'white',
                                border: '1px solid #e2e8f0',
                                borderRadius: '0.25rem',
                                fontSize: '0.8125rem',
                                color: '#475569'
                              }}
                            >
                              {tech}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </details>
            </div>

            {/* Tech Stack */}
            <div style={{ padding: '2rem', backgroundColor: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0' }}>
              <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Recommended Tech Stack</h2>
              <div style={{ display: 'grid', gap: '1rem' }}>
                {result.stack.map((item, idx) => (
                  <div key={idx} style={{ padding: '1rem', backgroundColor: '#f8fafc', borderRadius: '0.5rem', borderLeft: '3px solid #16a34a' }}>
                    <div style={{ fontWeight: 600, marginBottom: '0.25rem', fontSize: '1.0625rem' }}>
                      {item.category}: <span style={{ color: '#16a34a' }}>{item.tech}</span>
                    </div>
                    <div style={{ fontSize: '0.9375rem', color: '#64748b' }}>{item.reason}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Compliance */}
            {result.compliance.length > 0 && (
              <div style={{ padding: '2rem', backgroundColor: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0' }}>
                <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Compliance Standards</h2>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.75rem' }}>
                  {result.compliance.map((comp, idx) => (
                    <span
                      key={idx}
                      style={{
                        padding: '0.5rem 1rem',
                        backgroundColor: '#f0fdf4',
                        border: '1px solid #86efac',
                        borderRadius: '0.5rem',
                        color: '#15803d',
                        fontWeight: 500,
                        fontSize: '0.9375rem'
                      }}
                    >
                      {comp}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Risks */}
            {result.risks.length > 0 && (
              <div style={{ padding: '2rem', backgroundColor: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0' }}>
                <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Risk Assessment</h2>
                <div style={{ display: 'grid', gap: '0.75rem' }}>
                  {result.risks.map((risk, idx) => (
                    <div
                      key={idx}
                      style={{
                        padding: '1rem 1rem 1rem 1.25rem',
                        borderLeft: `4px solid ${risk.level === 'high' ? '#ef4444' :
                          risk.level === 'medium' ? '#f59e0b' : '#10b981'
                          }`,
                        backgroundColor: '#f8fafc',
                        borderRadius: '0.25rem'
                      }}
                    >
                      <span style={{
                        fontWeight: 700,
                        textTransform: 'uppercase',
                        fontSize: '0.75rem',
                        color: risk.level === 'high' ? '#ef4444' :
                          risk.level === 'medium' ? '#f59e0b' : '#10b981',
                        letterSpacing: '0.05em'
                      }}>
                        {risk.level} RISK:
                      </span>{' '}
                      <span style={{ color: '#475569' }}>{risk.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default ArchitectureEngine;