import React, { useState } from 'react';
import { Calculator, TrendingDown, AlertCircle, CheckCircle2, ExternalLink, Download } from 'lucide-react';
import { GoogleGenerativeAI } from '@google/generative-ai';

interface ROIInputs {
    company_size: 'small' | 'medium' | 'large' | 'enterprise' | '';
    industry_segment: 'pharma' | 'hospital' | 'clinic' | 'medtech' | 'payer' | '';
    current_cloud_spend_monthly: string;
    patient_records_count: string;
    compliance_status: 'non_compliant' | 'partially_compliant' | 'compliant_but_risky' | 'fully_compliant' | '';
    current_infrastructure: 'on_premise' | 'hybrid' | 'cloud_native' | '';
    challenges: string[];
    timeline: 'urgent' | '1-3mo' | '3-6mo' | 'planning' | '';
    budget_range: '<100k' | '100k-500k' | '500k-2m' | '>2m' | 'unsure' | '';
}

interface ROIResult {
    total_annual_savings: number;
    confidence_score: number;
    breakdown: {
        compliance_risk_reduction: { amount: number; description: string };
        infrastructure_optimization: { amount: number; description: string };
        operational_efficiency: { amount: number; description: string };
        avoided_penalties: { amount: number; description: string };
    };
    timeline_phases: {
        phase1: { duration: string; focus: string; savings: string };
        phase2: { duration: string; focus: string; savings: string };
        phase3: { duration: string; focus: string; savings: string };
    };
    relevant_case_studies: Array<{
        client: string;
        similarity_score: number;
        outcome: string;
        link: string;
    }>;
    risk_factors: Array<{
        risk: string;
        mitigation: string;
    }>;
}

const ROICalculator: React.FC = () => {
    const [inputs, setInputs] = useState<ROIInputs>({
        company_size: '',
        industry_segment: '',
        current_cloud_spend_monthly: '',
        patient_records_count: '',
        compliance_status: '',
        current_infrastructure: '',
        challenges: [],
        timeline: '',
        budget_range: ''
    });

    const [result, setResult] = useState<ROIResult | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const challengeOptions = [
        'Failing HIPAA audits',
        'High compliance audit costs',
        'Slow system performance',
        'Downtime risk',
        'Data breach concerns',
        'Legacy system EOL',
        'High operational costs',
        'Scalability issues'
    ];

    const handleChallengeToggle = (challenge: string) => {
        setInputs(prev => ({
            ...prev,
            challenges: prev.challenges.includes(challenge)
                ? prev.challenges.filter(c => c !== challenge)
                : [...prev.challenges, challenge]
        }));
    };

    const calculateROI = async () => {
        // Validation
        if (!inputs.current_cloud_spend_monthly || !inputs.patient_records_count) {
            setError('Please fill in at least cloud spend and record count');
            return;
        }

        setLoading(true);
        setError(null);

        try {
            const monthlySpend = parseFloat(inputs.current_cloud_spend_monthly);
            const records = parseInt(inputs.patient_records_count);

            // Base calculation (simplified for demo - would use AI in production)
            const complianceRisk = inputs.compliance_status === 'non_compliant' ? monthlySpend * 12 * 0.4 :
                inputs.compliance_status === 'partially_compliant' ? monthlySpend * 12 * 0.25 :
                    monthlySpend * 12 * 0.1;

            const infraOptimization = monthlySpend * 12 * 0.3; // 30% typical savings
            const operationalEfficiency = (records / 1000000) * 30000; // €30 per 1K records efficiency
            const avoidedPenalties = inputs.compliance_status === 'non_compliant' ? 50000 :
                inputs.compliance_status === 'partially_compliant' ? 25000 : 0;

            const totalSavings = complianceRisk + infraOptimization + operationalEfficiency + avoidedPenalties;

            // Calculate confidence based on data completeness
            let confidence = 70;
            if (inputs.company_size) confidence += 5;
            if (inputs.industry_segment) confidence += 5;
            if (inputs.compliance_status) confidence += 5;
            if (inputs.current_infrastructure) confidence += 5;
            if (inputs.challenges.length > 2) confidence += 10;

            // Find similar case studies
            const caseStudies = [
                {
                    client: 'PwC Healthcare',
                    similarity_score: inputs.compliance_status === 'non_compliant' ? 92 : 85,
                    outcome: '$500K saved, 70% traffic increase',
                    link: '/projects#pwc-healthcare'
                },
                {
                    client: 'Boehringer Ingelheim',
                    similarity_score: monthlySpend > 30000 ? 90 : 75,
                    outcome: '€500K migration, 50% faster insights',
                    link: '/projects#boehringer-aiml'
                }
            ].sort((a, b) => b.similarity_score - a.similarity_score).slice(0, 2);

            const calculatedResult: ROIResult = {
                total_annual_savings: Math.round(totalSavings),
                confidence_score: confidence,
                breakdown: {
                    compliance_risk_reduction: {
                        amount: Math.round(complianceRisk),
                        description: 'Reduced audit findings, faster certifications, lower consultant fees'
                    },
                    infrastructure_optimization: {
                        amount: Math.round(infraOptimization),
                        description: 'Right-sized instances, reserved capacity, automated scaling'
                    },
                    operational_efficiency: {
                        amount: Math.round(operationalEfficiency),
                        description: '3x faster queries, automated backups, reduced manual processes'
                    },
                    avoided_penalties: {
                        amount: Math.round(avoidedPenalties),
                        description: 'Avoided HIPAA violation fines and compliance penalties'
                    }
                },
                timeline_phases: {
                    phase1: {
                        duration: '2-4 weeks',
                        focus: 'Compliance audit & architecture design',
                        savings: 'Quick wins: €' + Math.round(infraOptimization * 0.1).toLocaleString()
                    },
                    phase2: {
                        duration: '8-12 weeks',
                        focus: 'Migration execution',
                        savings: 'Realized: €' + Math.round(totalSavings * 0.5).toLocaleString() + '/year'
                    },
                    phase3: {
                        duration: '4-6 weeks',
                        focus: 'Optimization & validation',
                        savings: 'Full ROI: €' + Math.round(totalSavings).toLocaleString() + '/year'
                    }
                },
                relevant_case_studies: caseStudies,
                risk_factors: [
                    {
                        risk: 'Data breach during migration',
                        mitigation: 'Zero-downtime strategy with encryption in transit and at rest. 12 migrations, zero breaches.'
                    },
                    {
                        risk: 'Extended downtime',
                        mitigation: 'Parallel systems with blue-green deployment. Users never experience disruption.'
                    },
                    {
                        risk: 'Cost overruns',
                        mitigation: 'Fixed-price phases with clear deliverables. No surprise costs.'
                    }
                ]
            };

            setResult(calculatedResult);
        } catch (err) {
            console.error('ROI calculation error:', err);
            setError('Error calculating ROI. Please check your inputs and try again.');
        } finally {
            setLoading(false);
        }
    };

    const formatCurrency = (amount: number) => {
        return '€' + amount.toLocaleString('de-DE', { maximumFractionDigits: 0 });
    };

    return (
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700">
            {/* Header */}
            <div className="bg-gradient-to-r from-emerald-600 to-blue-600 text-white p-6 rounded-t-2xl">
                <div className="flex items-center gap-3 mb-2">
                    <Calculator size={32} />
                    <h3 className="text-2xl font-bold">Healthcare Cloud Migration ROI Calculator</h3>
                </div>
                <p className="text-emerald-50">
                    Get a personalized estimate based on 12 successful healthcare migrations
                </p>
            </div>

            <div className="p-6 space-y-6">
                {/* Input Form */}
                <div className="grid md:grid-cols-2 gap-6">
                    {/* Company Size */}
                    <div>
                        <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Company Size *
                        </label>
                        <select
                            value={inputs.company_size}
                            onChange={(e) => setInputs({ ...inputs, company_size: e.target.value as any })}
                            className="w-full px-4 py-3 border-2 border-slate-300 dark:border-slate-600 rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:bg-slate-700 dark:text-white transition-all"
                        >
                            <option value="">Select...</option>
                            <option value="small">Small ({'<'} 50 employees)</option>
                            <option value="medium">Medium (50-500 employees)</option>
                            <option value="large">Large (500-2000 employees)</option>
                            <option value="enterprise">Enterprise ({'>'} 2000 employees)</option>
                        </select>
                    </div>

                    {/* Industry Segment */}
                    <div>
                        <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Healthcare Segment
                        </label>
                        <select
                            value={inputs.industry_segment}
                            onChange={(e) => setInputs({ ...inputs, industry_segment: e.target.value as any })}
                            className="w-full px-4 py-3 border-2 border-slate-300 dark:border-slate-600 rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:bg-slate-700 dark:text-white transition-all"
                        >
                            <option value="">Select...</option>
                            <option value="pharma">Pharmaceutical</option>
                            <option value="hospital">Hospital/Health System</option>
                            <option value="clinic">Clinic/Practice</option>
                            <option value="medtech">Medical Technology</option>
                            <option value="payer">Insurance/Payer</option>
                        </select>
                    </div>

                    {/* Current Cloud Spend */}
                    <div>
                        <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Current Monthly Cloud Spend (€) *
                        </label>
                        <input
                            type="number"
                            value={inputs.current_cloud_spend_monthly}
                            onChange={(e) => setInputs({ ...inputs, current_cloud_spend_monthly: e.target.value })}
                            placeholder="e.g., 50000"
                            className="w-full px-4 py-3 border-2 border-slate-300 dark:border-slate-600 rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:bg-slate-700 dark:text-white transition-all"
                        />
                    </div>

                    {/* Patient Records */}
                    <div>
                        <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Number of Patient Records *
                        </label>
                        <input
                            type="number"
                            value={inputs.patient_records_count}
                            onChange={(e) => setInputs({ ...inputs, patient_records_count: e.target.value })}
                            placeholder="e.g., 2000000"
                            className="w-full px-4 py-3 border-2 border-slate-300 dark:border-slate-600 rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:bg-slate-700 dark:text-white transition-all"
                        />
                    </div>

                    {/* Compliance Status */}
                    <div>
                        <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Current HIPAA Compliance Status *
                        </label>
                        <select
                            value={inputs.compliance_status}
                            onChange={(e) => setInputs({ ...inputs, compliance_status: e.target.value as any })}
                            className="w-full px-4 py-3 border-2 border-slate-300 dark:border-slate-600 rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:bg-slate-700 dark:text-white transition-all"
                        >
                            <option value="">Select...</option>
                            <option value="non_compliant">Not Compliant (failing audits)</option>
                            <option value="partially_compliant">Partially Compliant (some gaps)</option>
                            <option value="compliant_but_risky">Compliant but Risky (old systems)</option>
                            <option value="fully_compliant">Fully Compliant</option>
                        </select>
                    </div>

                    {/* Current Infrastructure */}
                    <div>
                        <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Current Infrastructure
                        </label>
                        <select
                            value={inputs.current_infrastructure}
                            onChange={(e) => setInputs({ ...inputs, current_infrastructure: e.target.value as any })}
                            className="w-full px-4 py-3 border-2 border-slate-300 dark:border-slate-600 rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:bg-slate-700 dark:text-white transition-all"
                        >
                            <option value="">Select...</option>
                            <option value="on_premise">On-Premise Only</option>
                            <option value="hybrid">Hybrid (On-Prem + Cloud)</option>
                            <option value="cloud_native">Already Cloud-Native</option>
                        </select>
                    </div>

                    {/* Timeline */}
                    <div>
                        <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Migration Timeline
                        </label>
                        <select
                            value={inputs.timeline}
                            onChange={(e) => setInputs({ ...inputs, timeline: e.target.value as any })}
                            className="w-full px-4 py-3 border-2 border-slate-300 dark:border-slate-600 rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:bg-slate-700 dark:text-white transition-all"
                        >
                            <option value="">Select...</option>
                            <option value="urgent">Urgent ({'<'} 1 month)</option>
                            <option value="1-3mo">1-3 months</option>
                            <option value="3-6mo">3-6 months</option>
                            <option value="planning">Planning / Exploratory</option>
                        </select>
                    </div>

                    {/* Budget Range */}
                    <div>
                        <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Budget Range
                        </label>
                        <select
                            value={inputs.budget_range}
                            onChange={(e) => setInputs({ ...inputs, budget_range: e.target.value as any })}
                            className="w-full px-4 py-3 border-2 border-slate-300 dark:border-slate-600 rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:bg-slate-700 dark:text-white transition-all"
                        >
                            <option value="">Select...</option>
                            <option value="<100k">{'<'} €100K</option>
                            <option value="100k-500k">€100K - €500K</option>
                            <option value="500k-2m">€500K - €2M</option>
                            <option value=">2m">{'>'} €2M</option>
                            <option value="unsure">Not Sure Yet</option>
                        </select>
                    </div>
                </div>

                {/* Challenges Checkboxes */}
                <div>
                    <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">
                        What are your biggest challenges? (Select all that apply)
                    </label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {challengeOptions.map((challenge) => (
                            <label
                                key={challenge}
                                className="flex items-center gap-2 cursor-pointer group"
                            >
                                <input
                                    type="checkbox"
                                    checked={inputs.challenges.includes(challenge)}
                                    onChange={() => handleChallengeToggle(challenge)}
                                    className="w-5 h-5 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                                />
                                <span className="text-sm text-slate-600 dark:text-slate-300 group-hover:text-emerald-600 transition-colors">
                                    {challenge}
                                </span>
                            </label>
                        ))}
                    </div>
                </div>

                {/* Error Message */}
                {error && (
                    <div className="bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500 p-4 rounded">
                        <div className="flex items-center gap-2">
                            <AlertCircle className="text-red-500" size={20} />
                            <p className="text-red-700 dark:text-red-400">{error}</p>
                        </div>
                    </div>
                )}

                {/* Calculate Button */}
                <button
                    onClick={calculateROI}
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-700 hover:to-blue-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all duration-300 shadow-xl hover:shadow-2xl disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                >
                    {loading ? (
                        <>
                            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white" />
                            Calculating...
                        </>
                    ) : (
                        <>
                            <Calculator size={24} />
                            Calculate My Potential Savings
                        </>
                    )}
                </button>

                {/* Results */}
                {result && (
                    <div className="mt-8 space-y-6 animate-fade-in">
                        {/* Hero Result */}
                        <div className="bg-gradient-to-br from-emerald-500 to-blue-600 text-white rounded-2xl p-8 text-center shadow-2xl">
                            <div className="text-sm uppercase tracking-wider mb-2 text-emerald-100">
                                Your Estimated Annual Savings
                            </div>
                            <div className="text-6xl font-bold mb-4">
                                {formatCurrency(result.total_annual_savings)}
                            </div>
                            <div className="flex items-center justify-center gap-2 text-emerald-100">
                                <CheckCircle2 size={20} />
                                <span>Confidence Score: {result.confidence_score}%</span>
                            </div>
                        </div>

                        {/* Breakdown */}
                        <div>
                            <h4 className="text-xl font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                                <TrendingDown className="text-emerald-600" />
                                Savings Breakdown
                            </h4>
                            <div className="grid md:grid-cols-2 gap-4">
                                {Object.entries(result.breakdown).map(([key, value]) => (
                                    <div
                                        key={key}
                                        className="bg-slate-50 dark:bg-slate-900 rounded-xl p-6 border-2 border-slate-200 dark:border-slate-700 hover:border-emerald-500 transition-all"
                                    >
                                        <div className="text-2xl font-bold text-emerald-600 mb-2">
                                            {formatCurrency(value.amount)}
                                        </div>
                                        <div className="text-sm font-semibold text-slate-900 dark:text-white mb-2 capitalize">
                                            {key.replace(/_/g, ' ')}
                                        </div>
                                        <p className="text-sm text-slate-600 dark:text-slate-400">
                                            {value.description}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Timeline */}
                        <div>
                            <h4 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
                                Implementation Timeline
                            </h4>
                            <div className="space-y-4">
                                {Object.entries(result.timeline_phases).map(([key, phase]) => (
                                    <div
                                        key={key}
                                        className="bg-white dark:bg-slate-800 rounded-xl p-6 border-l-4 border-emerald-500 shadow-md"
                                    >
                                        <div className="flex items-start justify-between mb-2">
                                            <div>
                                                <div className="font-bold text-slate-900 dark:text-white">
                                                    {phase.duration}
                                                </div>
                                                <div className="text-slate-600 dark:text-slate-400">
                                                    {phase.focus}
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <div className="text-sm text-slate-500 dark:text-slate-400">Savings</div>
                                                <div className="font-bold text-emerald-600">{phase.savings}</div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Case Studies */}
                        <div>
                            <h4 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
                                Relevant Projects I've Delivered
                            </h4>
                            <div className="grid md:grid-cols-2 gap-4">
                                {result.relevant_case_studies.map((study, idx) => (
                                    <div
                                        key={idx}
                                        className="bg-slate-50 dark:bg-slate-900 rounded-xl p-6 border border-slate-200 dark:border-slate-700 hover:border-emerald-500 transition-all"
                                    >
                                        <div className="flex items-start justify-between mb-3">
                                            <h5 className="font-bold text-slate-900 dark:text-white">
                                                {study.client}
                                            </h5>
                                            <div className="bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 px-3 py-1 rounded-full text-xs font-bold">
                                                {study.similarity_score}% match
                                            </div>
                                        </div>
                                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                                            {study.outcome}
                                        </p>
                                        <a
                                            href={study.link}
                                            className="inline-flex items-center gap-2 text-emerald-600 font-semibold text-sm hover:gap-3 transition-all"
                                        >
                                            View Full Case Study
                                            <ExternalLink size={16} />
                                        </a>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Risk Factors */}
                        <div>
                            <h4 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
                                Risk Mitigation
                            </h4>
                            <div className="space-y-3">
                                {result.risk_factors.map((factor, idx) => (
                                    <div
                                        key={idx}
                                        className="bg-white dark:bg-slate-800 rounded-xl p-4 border border-slate-200 dark:border-slate-700"
                                    >
                                        <div className="flex items-start gap-3">
                                            <AlertCircle className="text-amber-500 flex-shrink-0 mt-0.5" size={20} />
                                            <div className="flex-grow">
                                                <div className="font-semibold text-slate-900 dark:text-white mb-1">
                                                    Risk: {factor.risk}
                                                </div>
                                                <div className="text-sm text-slate-600 dark:text-slate-400 flex items-start gap-2">
                                                    <CheckCircle2 className="text-emerald-600 flex-shrink-0 mt-0.5" size={16} />
                                                    {factor.mitigation}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* CTA */}
                        <div className="bg-gradient-to-r from-emerald-600 to-blue-600 rounded-2xl p-8 text-white text-center">
                            <h4 className="text-2xl font-bold mb-4">
                                Ready to Achieve These Savings?
                            </h4>
                            <p className="text-emerald-100 mb-6">
                                Based on your inputs, you're an excellent fit for my services.
                                Let's discuss your specific situation in a free 30-minute consultation.
                            </p>
                            <div className="flex flex-col sm:flex-row gap-4 justify-center">
                                <a
                                    href="https://calendly.com/prasadtilloo/30min"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="bg-white text-emerald-600 px-8 py-4 rounded-xl font-bold hover:bg-emerald-50 transition-all inline-flex items-center justify-center gap-2"
                                >
                                    <CheckCircle2 size={20} />
                                    Book Free Consultation
                                </a>
                                <button
                                    onClick={() => window.print()}
                                    className="bg-white/10 backdrop-blur-sm text-white border-2 border-white px-8 py-4 rounded-xl font-bold hover:bg-white/20 transition-all inline-flex items-center justify-center gap-2"
                                >
                                    <Download size={20} />
                                    Save Results (PDF)
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ROICalculator;
