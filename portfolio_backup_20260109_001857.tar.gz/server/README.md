This server has been disabled as part of reverting the ChatAssistant and RAG features. A backup of the original files is stored in `.reverts/chatassistant_backup`.
