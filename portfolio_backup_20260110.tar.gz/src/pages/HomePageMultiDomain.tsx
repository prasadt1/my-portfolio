import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
    ArrowRight,
    ArrowDown,
    CheckCircle2,
    Building2,
    Shield,
    Leaf
} from 'lucide-react';
import SEO from '../components/SEO';

const HomePageMultiDomain: React.FC = () => {
    return (
        <>
            <SEO
                title="Enterprise Transformation: Services + Products"
                description="15+ years architecting digital transformation. Consulting services + battle-tested toolkits for enterprise modernization, compliance, and sustainability tech."
                keywords="enterprise architecture, digital transformation, Industry 4.0, HIPAA compliance, PACT protocol, carbon transparency, IT consulting, PwC"
                type="website"
            />

            <div className="min-h-screen font-sans">
                {/* HERO SECTION - Simplified & Larger Typography */}
                <section className="relative bg-slate-50 dark:bg-gradient-to-br dark:from-slate-900 dark:via-slate-800 dark:to-emerald-900 transition-colors duration-300 py-32 md:py-48 overflow-hidden">
                    {/* Background Pattern */}
                    <div className="absolute inset-0 opacity-10 dark:opacity-20 pointer-events-none">
                        <div className="absolute inset-0 bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] dark:bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]"></div>
                    </div>

                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6 }}
                            className="text-center"
                        >
                            <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold mb-8 leading-none tracking-tight text-slate-900 dark:text-white">
                                Stop Wasting 6 Months Building
                                <br />
                                <span className="text-emerald-600 dark:text-emerald-400">What I've Already Built</span>
                            </h1>

                            <p className="text-2xl md:text-3xl text-slate-600 dark:text-slate-200 mb-12 max-w-4xl mx-auto leading-relaxed">
                                Battle-tested toolkits + consulting from 15 years architecting
                                Fortune 500 transformations.
                            </p>

                            <div className="flex flex-col items-center gap-4 animate-bounce">
                                <a
                                    href="#path-selector"
                                    className="text-xl text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 flex items-center gap-2 font-semibold"
                                >
                                    What brings you here today? <ArrowDown size={24} />
                                </a>
                            </div>
                        </motion.div>
                    </div>
                </section>

                {/* PATH SELECTOR - NEW SECTION */}
                <section id="path-selector" className="py-32 bg-white dark:bg-slate-800 scroll-mt-20">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <motion.div
                            initial={{ opacity: 0 }}
                            whileInView={{ opacity: 1 }}
                            viewport={{ once: true }}
                            className="text-center mb-20"
                        >
                            <h2 className="text-5xl md:text-6xl font-bold mb-6 text-slate-900 dark:text-white">
                                What Do You Need?
                            </h2>
                            <p className="text-2xl text-slate-600 dark:text-slate-300">
                                Choose your path to get started
                            </p>
                        </motion.div>

                        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                            {/* Option 1: Custom Consulting */}
                            <motion.div
                                initial={{ opacity: 0, y: 30 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                className="group bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-3xl p-10 border-2 border-blue-200 dark:border-blue-700 hover:border-blue-500 hover:shadow-2xl transition-all duration-300 cursor-pointer flex flex-col"
                            >
                                <div className="text-7xl mb-6">🤝</div>
                                <h3 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
                                    Custom Consulting
                                </h3>
                                <p className="text-lg text-slate-600 dark:text-slate-300 mb-8 flex-grow">
                                    Complex transformation requiring hands-on architecture expertise
                                </p>
                                <ul className="space-y-3 mb-8 text-base">
                                    <li className="flex items-start gap-3">
                                        <CheckCircle2 className="text-blue-600 flex-shrink-0 mt-0.5" size={20} />
                                        <span className="text-slate-700 dark:text-slate-200">Enterprise modernization</span>
                                    </li>
                                    <li className="flex items-start gap-3">
                                        <CheckCircle2 className="text-blue-600 flex-shrink-0 mt-0.5" size={20} />
                                        <span className="text-slate-700 dark:text-slate-200">Compliance implementation</span>
                                    </li>
                                    <li className="flex items-start gap-3">
                                        <CheckCircle2 className="text-blue-600 flex-shrink-0 mt-0.5" size={20} />
                                        <span className="text-slate-700 dark:text-slate-200">Sustainability tech</span>
                                    </li>
                                </ul>
                                <a
                                    href="https://calendly.com/prasadtilloo/30min"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="block w-full text-center bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all shadow-lg hover:shadow-blue-500/30"
                                >
                                    Book Strategy Call
                                </a>
                                <p className="text-center text-sm text-slate-500 dark:text-slate-400 mt-4 font-medium">
                                    €300/hour
                                </p>
                            </motion.div>

                            {/* Option 2: Ready-Made Products */}
                            <motion.div
                                initial={{ opacity: 0, y: 30 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: 0.1 }}
                                className="group bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-900/20 dark:to-emerald-800/20 rounded-3xl p-10 border-2 border-emerald-200 dark:border-emerald-700 hover:border-emerald-500 hover:shadow-2xl transition-all duration-300 cursor-pointer flex flex-col relative overflow-hidden"
                            >
                                <div className="absolute top-0 right-0 bg-emerald-500 text-white text-xs font-bold px-4 py-2 rounded-bl-xl uppercase tracking-wider">Most Popular</div>
                                <div className="text-7xl mb-6">📦</div>
                                <h3 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
                                    Ready-Made Solutions
                                </h3>
                                <p className="text-lg text-slate-600 dark:text-slate-300 mb-8 flex-grow">
                                    Battle-tested toolkits to accelerate your transformation
                                </p>
                                <ul className="space-y-3 mb-8 text-base">
                                    <li className="flex items-start gap-3">
                                        <CheckCircle2 className="text-emerald-600 flex-shrink-0 mt-0.5" size={20} />
                                        <span className="text-slate-700 dark:text-slate-200">Industry 4.0 frameworks</span>
                                    </li>
                                    <li className="flex items-start gap-3">
                                        <CheckCircle2 className="text-emerald-600 flex-shrink-0 mt-0.5" size={20} />
                                        <span className="text-slate-700 dark:text-slate-200">Compliance packages</span>
                                    </li>
                                    <li className="flex items-start gap-3">
                                        <CheckCircle2 className="text-emerald-600 flex-shrink-0 mt-0.5" size={20} />
                                        <span className="text-slate-700 dark:text-slate-200">Assessment tools</span>
                                    </li>
                                </ul>
                                <Link
                                    to="/products"
                                    className="block w-full text-center bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all shadow-lg hover:shadow-emerald-500/30"
                                >
                                    Browse Products
                                </Link>
                                <p className="text-center text-sm text-slate-500 dark:text-slate-400 mt-4 font-medium">
                                    €1,000 - €15,000
                                </p>
                            </motion.div>

                            {/* Option 3: View Proof */}
                            <motion.div
                                initial={{ opacity: 0, y: 30 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: 0.2 }}
                                className="group bg-gradient-to-br from-violet-50 to-violet-100 dark:from-violet-900/20 dark:to-violet-800/20 rounded-3xl p-10 border-2 border-violet-200 dark:border-violet-700 hover:border-violet-500 hover:shadow-2xl transition-all duration-300 cursor-pointer flex flex-col"
                            >
                                <div className="text-7xl mb-6">🔍</div>
                                <h3 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
                                    See the Proof
                                </h3>
                                <p className="text-lg text-slate-600 dark:text-slate-300 mb-8 flex-grow">
                                    Explore case studies and real project outcomes
                                </p>
                                <ul className="space-y-3 mb-8 text-base">
                                    <li className="flex items-start gap-3">
                                        <CheckCircle2 className="text-violet-600 flex-shrink-0 mt-0.5" size={20} />
                                        <span className="text-slate-700 dark:text-slate-200">Fortune 500 projects</span>
                                    </li>
                                    <li className="flex items-start gap-3">
                                        <CheckCircle2 className="text-violet-600 flex-shrink-0 mt-0.5" size={20} />
                                        <span className="text-slate-700 dark:text-slate-200">€2M+ delivered</span>
                                    </li>
                                    <li className="flex items-start gap-3">
                                        <CheckCircle2 className="text-violet-600 flex-shrink-0 mt-0.5" size={20} />
                                        <span className="text-slate-700 dark:text-slate-200">12 compliance migrations</span>
                                    </li>
                                </ul>
                                <Link
                                    to="/projects"
                                    className="block w-full text-center bg-violet-600 hover:bg-violet-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all shadow-lg hover:shadow-violet-500/30"
                                >
                                    View Case Studies
                                </Link>
                                <p className="text-center text-sm text-slate-500 dark:text-slate-400 mt-4 font-medium">
                                    Free to explore
                                </p>
                            </motion.div>
                        </div>
                    </div>
                </section>

                {/* SIMPLIFIED 3 PILLARS */}
                <section className="py-32 bg-slate-50 dark:bg-slate-900">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <h2 className="text-5xl font-bold text-center mb-16 text-slate-900 dark:text-white">
                            Expertise Across Three Pillars
                        </h2>

                        <div className="grid md:grid-cols-3 gap-8">
                            {/* Pillar 1 */}
                            <div className="bg-white dark:bg-slate-800 rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all group">
                                <Building2 className="w-16 h-16 text-blue-600 mb-6 group-hover:scale-110 transition-transform" />
                                <h3 className="text-2xl font-bold mb-4 text-slate-900 dark:text-white">
                                    Enterprise Modernization
                                </h3>
                                <p className="text-lg text-slate-600 dark:text-slate-300 mb-6">
                                    Legacy systems, cloud migration, Industry 4.0
                                </p>
                                <Link
                                    to="/projects?category=modernization"
                                    className="text-blue-600 font-bold hover:text-blue-700 flex items-center gap-2 text-lg hover:gap-3 transition-all"
                                >
                                    View Projects <ArrowRight size={20} />
                                </Link>
                            </div>

                            {/* Pillar 2 */}
                            <div className="bg-white dark:bg-slate-800 rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all group">
                                <Shield className="w-16 h-16 text-violet-600 mb-6 group-hover:scale-110 transition-transform" />
                                <h3 className="text-2xl font-bold mb-4 text-slate-900 dark:text-white">
                                    Compliance Engineering
                                </h3>
                                <p className="text-lg text-slate-600 dark:text-slate-300 mb-6">
                                    HIPAA, GDPR, FHIR, IT effectiveness
                                </p>
                                <Link
                                    to="/projects?category=compliance"
                                    className="text-violet-600 font-bold hover:text-violet-700 flex items-center gap-2 text-lg hover:gap-3 transition-all"
                                >
                                    View Projects <ArrowRight size={20} />
                                </Link>
                            </div>

                            {/* Pillar 3 */}
                            <div className="bg-white dark:bg-slate-800 rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all relative group border-2 border-emerald-500/20">
                                <div className="absolute -top-3 -right-3 bg-amber-400 text-slate-900 px-4 py-1 rounded-full text-xs font-black uppercase tracking-wider shadow-md">
                                    UNIQUE
                                </div>
                                <Leaf className="w-16 h-16 text-emerald-600 mb-6 group-hover:scale-110 transition-transform" />
                                <h3 className="text-2xl font-bold mb-4 text-slate-900 dark:text-white">
                                    Sustainability Tech
                                </h3>
                                <p className="text-lg text-slate-600 dark:text-slate-300 mb-6">
                                    PACT Protocol, carbon transparency, ESG
                                </p>
                                <Link
                                    to="/projects/pact-carbon-transparency"
                                    className="text-emerald-600 font-bold hover:text-emerald-700 flex items-center gap-2 text-lg hover:gap-3 transition-all"
                                >
                                    View Projects <ArrowRight size={20} />
                                </Link>
                            </div>
                        </div>
                    </div>
                </section>

                {/* SUBTLE TRUST BAR */}
                <div className="py-16 bg-white dark:bg-slate-800 border-y border-slate-200 dark:border-slate-700">
                    <div className="max-w-7xl mx-auto px-4">
                        <p className="text-center text-sm uppercase tracking-widest text-slate-400 mb-10 font-bold">
                            Trusted By Global Leaders
                        </p>
                        <div className="flex flex-wrap justify-center items-center gap-12 md:gap-20 opacity-40 hover:opacity-100 transition-opacity duration-500 grayscale hover:grayscale-0">
                            {/* Full Client List - Subtle */}
                            <img src="/assets/logos/PricewaterhouseCoopers_Logo.svg" alt="PwC" className="h-8 w-auto object-contain dark:brightness-0 dark:invert" />
                            <svg viewBox="0 0 24 24" fill="none" className="h-10 w-auto text-[#003366] dark:text-white fill-current"><path d="M5.41 22.03c-1.72-1.24-2.63-2.15-3.49-3.46A12.185 12.185 0 0 1 0 12.03C0 5.38 5.36 0 12 0s12 5.38 12 12c0 2.73-.93 5.46-2.58 7.48-.68.86-1.26 1.36-2.83 2.55v-7.02h1.19v4.8c.88-1.04 1.31-1.67 1.74-2.43.88-1.57 1.36-3.51 1.36-5.38 0-6.06-4.88-10.99-10.89-10.99S1.11 5.94 1.11 12.08c0 2.8.99 5.28 3.08 7.73v-4.8H5.4v7.02Zm2.37 1.21c-.23-.05-.76-.3-1.19-.53V15h1.19v8.24Zm7.23-16.92L12 4 8.99 6.32l-.66-.86 3.66-2.86 3.66 2.86-.66.86Zm-4.83 17.56c-.43-.08-.45-.08-.61-.13-.13-.02-.18-.02-.58-.13V7.2h1.19v16.67Zm2.4.1c-.18.02-.23.02-.48.02-.38 0-.51 0-.71-.02V7.2h1.19v16.78Zm2.4-.38c-.38.13-.71.2-1.19.3V7.2h1.19v16.4Zm2.43-.88c-.38.18-.61.28-1.21.56v-8.27h1.21v7.71Z" /></svg>
                            <img src="/assets/logos/Lonza_Logo.svg" alt="Lonza" className="h-10 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/astrazeneca-1.svg" alt="AstraZeneca" className="h-8 w-auto object-contain dark:brightness-0 dark:invert" />
                            <svg viewBox="0 0 1000 220" fill="none" className="h-8 w-auto"><rect x="0" y="0" width="100" height="100" fill="#F25022" /><rect x="110" y="0" width="100" height="100" fill="#7FBA00" /><rect x="0" y="110" width="100" height="100" fill="#00A4EF" /><rect x="110" y="110" width="100" height="100" fill="#FFB900" /><text x="260" y="160" fontFamily="Segoe UI, Arial, sans-serif" fontWeight="600" fontSize="150" fill="#737373" className="dark:fill-white">Microsoft</text></svg>
                            <img src="/assets/logos/SAP_2011_logo.svg" alt="SAP" className="h-14 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/Pfizer_(2021).svg" alt="Pfizer" className="h-10 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/BMW.svg" alt="BMW" className="h-14 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/Novartis-Logo.svg" alt="Novartis" className="h-8 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/WBCSD.svg" alt="WBCSD" className="h-10 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/PG.svg" alt="P&G" className="h-14 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/Unilever.svg" alt="Unilever" className="h-10 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/Siemens-logo.svg" alt="Siemens" className="h-6 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/Mercedes-Logo.svg" alt="Mercedes" className="h-14 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/Brita_(Unternehmen)_logo.svg" alt="Brita" className="h-8 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/Delivery-Hero-Logo-Red.png" alt="Delivery Hero" className="h-12 w-auto object-contain grayscale dark:invert dark:brightness-100" />
                            <img src="/assets/logos/Comcast.svg" alt="Comcast" className="h-6 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/KP_logo.svg" alt="Kaiser Permanente" className="h-6 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/AmeriHealth.svg" alt="AmeriHealth" className="h-8 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/PMI.svg" alt="PMI" className="h-12 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/DaVita_logo.svg" alt="DaVita" className="h-8 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/Ameritas-01.svg" alt="Ameritas" className="h-14 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/Anthem.svg" alt="Anthem" className="h-8 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/blue-cross-blue-shield-1.svg" alt="BCBS" className="h-10 w-auto object-contain dark:brightness-0 dark:invert" />
                            <img src="/assets/logos/ecovadis-vector-logo.svg" alt="EcoVadis" className="h-6 w-auto object-contain dark:brightness-0 dark:invert" />
                        </div>
                    </div>
                </div>

                {/* FINAL CTA - Simplified */}
                <section className="py-24 bg-gradient-to-br from-slate-900 to-slate-800 text-white text-center">
                    <div className="max-w-4xl mx-auto px-4">
                        <h2 className="text-4xl md:text-5xl font-bold mb-8">
                            Ready to Transform?
                        </h2>
                        <a
                            href="#path-selector"
                            className="inline-block bg-emerald-600 hover:bg-emerald-500 text-white px-10 py-5 rounded-full font-bold text-xl shadow-2xl hover:scale-105 transition-all"
                        >
                            Choose Your Path
                        </a>
                    </div>
                </section>
            </div>
        </>
    );
};

export default HomePageMultiDomain;
