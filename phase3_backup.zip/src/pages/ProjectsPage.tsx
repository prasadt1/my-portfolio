import React, { useState, useMemo, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { projects, Project } from './projects';
import { Search, FolderGit2, Calendar, Building2, Tag, Layers } from 'lucide-react';

import SmartProjectFilter from '../components/SmartProjectFilter';

const ProjectsPage: React.FC = () => {
  const location = useLocation();
  const [filter, setFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [smartTags, setSmartTags] = useState<string[]>([]);
  const [isSmartFilterActive, setIsSmartFilterActive] = useState(false);

  useEffect(() => {
    if (location.state && location.state.filter) {
      setFilter(location.state.filter);
    }
  }, [location.state]);

  // Extended filters to match Home Page industries
  const filters = ['All', 'Cloud', 'AI/ML', 'Healthcare', 'Financial', 'E-commerce', 'Climate-Tech', 'AdTech', 'Telecom', 'Manufacturing'];

  const allProjectTags = Array.from(new Set(projects.flatMap(p => p.tags).concat(projects.flatMap(p => p.techStack))));

  const handleSmartFilter = (tags: string[]) => {
    setSmartTags(tags);
    setIsSmartFilterActive(true);
    setFilter('All'); // Reset category filter
    setSearchQuery(''); // Reset text search
  };

  const clearSmartFilter = () => {
    setIsSmartFilterActive(false);
    setSmartTags([]);
  };

  const filteredProjects = useMemo(() => {
    return projects.filter(project => {
      if (isSmartFilterActive) {
        // If smart filter is active, check if project has ANY of the returned tags
        // We can make this stricter (ALL tags) if desired, but ANY is usually better for "Show me projects with X or Y"
        const projectTags = [...project.tags, ...project.techStack, ...project.industries];
        return smartTags.some(tag => projectTags.some(pt => pt.toLowerCase().includes(tag.toLowerCase()) || tag.toLowerCase().includes(pt.toLowerCase())));
      }

      const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.techStack.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

      if (filter === 'All') return matchesSearch;

      // Mapping simple filter names to complex data matches
      const categories: Record<string, boolean> = {
        'Cloud': project.tags.some(t => ['Cloud', 'AWS', 'Azure', 'GCP'].some(k => t.includes(k))) || project.techStack.some(t => ['AWS', 'Azure'].includes(t)),
        'AI/ML': project.tags.includes('AI') || project.tags.includes('AI/ML') || project.industries.includes('aiml'),
        'Healthcare': project.industries.includes('healthcare'),
        'Financial': project.industries.includes('financial') || project.tags.includes('FinTech'),
        'E-commerce': project.industries.includes('ecommerce'),
        'Climate-Tech': project.industries.includes('climate-tech'),
        'AdTech': project.industries.includes('adtech'),
        'Telecom': project.industries.includes('telecom'),
        'Manufacturing': project.industries.includes('manufacturing')
      };

      return categories[filter] && matchesSearch;
    });
  }, [filter, searchQuery, isSmartFilterActive, smartTags]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 pt-24 pb-20 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">

        {/* Header Section */}
        <div className="space-y-6 text-center max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-white tracking-tight font-serif">
              Selected Works
            </h1>
            <p className="mt-4 text-lg text-slate-600 dark:text-slate-400 leading-relaxed">
              A showcase of technical leadership, cloud architecture, and digital transformation initiatives delivering tangible business value.
            </p>
          </motion.div>

          <SmartProjectFilter onFilter={handleSmartFilter} availableTags={allProjectTags} />

          {isSmartFilterActive && (
            <div className="flex items-center justify-center gap-2 mb-4">
              <span className="text-sm text-slate-500 dark:text-slate-400">Showing results for AI search:</span>
              <div className="flex gap-1">
                {smartTags.map(t => (
                  <span key={t} className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 rounded text-xs font-medium">{t}</span>
                ))}
              </div>
              <button onClick={clearSmartFilter} className="text-xs text-red-500 hover:underline ml-2">Clear AI Filter</button>
            </div>
          )}

          {/* Filter & Search Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className={`flex flex-col md:flex-row gap-4 justify-center items-center bg-white dark:bg-slate-800 p-2 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 ${isSmartFilterActive ? 'opacity-50 pointer-events-none grayscale' : ''}`}
          >
            <div className="flex overflow-x-auto pb-2 md:pb-0 gap-2 no-scrollbar w-full md:w-auto px-2">
              {filters.map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f as any)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${filter === f
                    ? 'bg-slate-900 dark:bg-emerald-600 text-white shadow-md'
                    : 'bg-transparent text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white'
                    }`}
                >
                  {f}
                </button>
              ))}
            </div>

            <div className="h-8 w-px bg-slate-200 dark:bg-slate-700 hidden md:block"></div>

            <div className="relative w-full md:w-64">
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search stack..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all text-sm text-slate-900 dark:text-white placeholder:text-slate-400"
              />
            </div>
          </motion.div>
        </div>

        {/* Projects Grid */}
        <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          <AnimatePresence>
            {filteredProjects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </AnimatePresence>
        </motion.div>

        {filteredProjects.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 mb-4">
              <FolderGit2 size={32} className="text-slate-400 dark:text-slate-500" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 dark:text-white">No projects found</h3>
            <p className="text-slate-500 dark:text-slate-400">Try adjusting your search or filters.</p>
          </motion.div>
        )}
      </div>
    </div>
  );
};

// Project Card Component
const ProjectCard: React.FC<{ project: Project }> = ({ project }) => {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3 }}
      className="group relative bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-xl hover:shadow-emerald-900/5 dark:hover:shadow-emerald-500/5 hover:-translate-y-1 transition-all duration-300 flex flex-col h-full overflow-hidden"
    >
      {/* Top Pattern Decoration */}
      <div className="h-2 bg-gradient-to-r from-slate-800 to-emerald-600 dark:from-slate-700 dark:to-emerald-500"></div>

      <div className="p-6 flex flex-col flex-1">
        {/* Header */}
        <div className="flex justify-between items-start mb-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-2">
              <Building2 size={12} />
              {project.company}
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white leading-snug group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition-colors">
              {project.title}
            </h3>
          </div>
        </div>

        {/* Meta */}
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-slate-500 dark:text-slate-400 mb-4 font-mono">
          <span className="flex items-center gap-1 bg-slate-50 dark:bg-slate-700 px-2 py-1 rounded">
            <Calendar size={12} /> {project.date}
          </span>
          <span className="flex items-center gap-1 bg-slate-50 dark:bg-slate-700 px-2 py-1 rounded">
            <Tag size={12} /> {project.role}
          </span>
        </div>

        {/* Description */}
        <div className="space-y-3 mb-6 flex-1">
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            <span className="font-semibold text-slate-900 dark:text-white">Challenge:</span> {project.challenge}
          </p>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            <span className="font-semibold text-slate-900 dark:text-white">Solution:</span> {project.solution}
          </p>
        </div>

        {/* Tech Stack Preview */}
        <div className="border-t border-slate-100 dark:border-slate-700 pt-4 mt-auto">
          <div className="flex items-center gap-2 mb-3 text-xs font-medium text-slate-400 dark:text-slate-500">
            <Layers size={14} /> Technology Stack
          </div>
          <div className="flex flex-wrap gap-2">
            {project.techStack.slice(0, 5).map((tech) => (
              <span
                key={tech}
                className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-md border border-slate-200/50 dark:border-slate-600/50"
              >
                {tech}
              </span>
            ))}
            {project.techStack.length > 5 && (
              <span className="px-2 py-1 text-[10px] text-slate-400 dark:text-slate-500">+ {project.techStack.length - 5} more</span>
            )}
          </div>
        </div>
      </div>

      {/* Hover Action Layer */}
      <div className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/[0.02] dark:group-hover:bg-white/[0.02] transition-colors pointer-events-none" />
    </motion.div>
  );
};

export default ProjectsPage;
