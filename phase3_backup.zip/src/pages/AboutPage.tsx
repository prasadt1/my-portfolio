import React from 'react';
import { Link } from 'react-router-dom';
import {
  Mail, MapPin, Linkedin, Github, Award, Briefcase,
  GraduationCap, Languages, Target, Heart, Zap, BookOpen,
  ChevronRight
} from 'lucide-react';
import { motion } from 'framer-motion';
import profilepic from '../assets/images/profilepic.png';
import TechChips from '../components/TechChips';
import Recommendations from '../components/Recommendations';
import SEO from '../components/SEO';
import QuickStats from '../components/QuickStats';

const AboutPage: React.FC = () => {
  const techCategories: Record<string, string[]> = {
    'Languages': ['C#', 'Java', 'JavaScript', 'HTML5', 'Python', 'TypeScript'],
    'Frontend': ['React', 'Redux', 'Vue.js', 'Next JS', 'Nuxt JS', 'Angular', 'Bootstrap', 'Vite'],
    'Backend': ['NodeJS', 'Express.js', 'Django', 'FastAPI', 'Spring', '.NET'],
    'Cloud': ['AWS', 'Azure', 'Google Cloud', 'Cloudflare', 'Heroku', 'Netlify', 'Vercel'],
    'Data & ML': ['PyTorch', 'NumPy', 'Matplotlib', 'Spark', 'Hadoop', 'Kafka'],
    'Databases': ['MongoDB', 'MySQL', 'Neo4J', 'Redis', 'DynamoDB', 'Cassandra', 'SQLite'],
    'DevOps': ['Kubernetes', 'Docker', 'Jenkins', 'CircleCI', 'GitHub Actions', 'TravisCI'],
    'Tools': ['Figma', 'Adobe Photoshop', 'Lightroom', 'Canva', 'Postman']
  };

  const experiences = [
    {
      company: 'BRITA',
      role: 'Solution Architect (DTC e-Commerce)',
      period: 'May 2025 – Nov 2025',
      location: 'Frankfurt, Germany',
      achievements: [
        'Led Shopware-to-Shopify Plus discovery across 6 EMEA markets',
        'Designed headless reference architecture with Vue.js/Nuxt.js and Azure',
        'Prototyped AI-driven search optimization for Google AI results'
      ]
    },
    {
      company: 'SINE Foundation e.V.',
      role: 'Senior Technical Project Manager / Lead Architect',
      period: 'Oct 2022 – Jun 2024',
      location: 'Berlin, Germany',
      achievements: [
        'Boosted adoption by 25% with PACT Online Catalog cloud marketplace',
        'Defined global Tech Specification for Product Carbon Footprint with Microsoft, SAP, Siemens',
        'Led WBCSD PACT Standard with 20+ Fortune 100 firms'
      ]
    },
    {
      company: 'Delivery Hero SE',
      role: 'Senior Engineering Manager (Freelance)',
      period: 'Mar 2022 – Sept 2022',
      location: 'Berlin, Germany',
      achievements: [
        'Increased revenue by 20% across EMEA region with Display Ads product',
        'Scaled to 5M+ daily transactions with 99.99% SLA compliance',
        'Led 10-member cross-functional team (iOS, Android, Golang)'
      ]
    },
    {
      company: 'Boehringer Ingelheim',
      role: 'Lead Architect',
      period: 'Nov 2020 - Feb 2022',
      location: 'Ingelheim, Germany',
      achievements: [
        'Accelerated AI/ML insights by 50% with Enterprise Data Lake',
        'Improved efficiency by 30% through digital transformation roadmap',
        'Led €500K cloud migration with GDPR/PCI compliance'
      ]
    },
    {
      company: 'PricewaterhouseCoopers (PwC)',
      role: 'Senior Manager',
      period: 'Mar 2015 – Oct 2020',
      location: 'Chicago, USA',
      achievements: [
        'Led a $650K cloud modernization program for e-commerce and healthcare systems.',
        'Designed pharmacy module boosting mobile app traffic by 70%.',
        'Co-developed cloud-based Enterprise Data Lake and domain-driven microservices.'
      ]
    },
    {
      company: 'Innova Solutions',
      role: 'Tech Lead / Engineering Manager',
      period: 'Jun 2009 - Feb 2015',
      location: 'New York, USA',
      achievements: [
        'Improved insurance client website performance by 80% via scalable data pipeline.',
        'Pioneered asynchronous account data ingestion system using Docker and Jenkins.'
      ]
    }
  ];

  const certifications = [
    { title: 'AI Agents Intensive', issuer: 'Google / Kaggle', date: 'Dec 2025' },
    { title: 'AI Engineering Cohort', issuer: 'ByteByteGo / ByteByteAI', date: 'Nov 2025', id: '14244ccc' },
    { title: 'Deutsch-Test für Zuwanderer (B1)', issuer: 'GAST e.V.', date: 'May 2025', id: 'G1098095' },
    { title: 'Artificial Intelligence Foundations', issuer: 'LinkedIn', date: 'Nov 2020' },
    { title: 'Certified SAFe® 4 DevOps Practitioner', issuer: 'Scaled Agile, Inc.', date: 'Aug 2019' },
    { title: 'Digital Accelerator', issuer: 'PwC', date: 'Aug 2019' },
    { title: 'Axelta Certified IoT Professional', issuer: 'Divigo.io', date: 'Mar 2016' },
    { title: 'Cybersecurity: Tech, App & Policy', issuer: 'MIT Professional', date: 'Mar 2016' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <SEO
        title="About"
        description="15+ years experience in enterprise architecture across healthcare, financial services, e-commerce. Led teams at PwC, Boehringer Ingelheim, Delivery Hero."
        keywords="enterprise architect experience, cloud migration, digital transformation"
        type="profile"
      />
      {/* Hero Section */}
      <div className="text-center mb-16 pb-12 border-b border-slate-200 dark:border-slate-800">
        <div className="w-40 h-40 mx-auto mb-8 rounded-full p-1 bg-gradient-to-tr from-emerald-500 to-slate-800">
          <div className="w-full h-full rounded-full overflow-hidden bg-slate-900 border-4 border-white dark:border-slate-800">
            <img
              src={profilepic}
              alt="Prasad Tilloo"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-5xl font-serif font-bold text-slate-900 dark:text-white mb-4"
        >
          Prasad Tilloo
        </motion.h1>

        <p className="text-xl md:text-2xl text-emerald-600 dark:text-emerald-400 font-semibold mb-3">
          Senior IT Leader | AI & Cloud Enabler
        </p>

        <p className="text-lg text-slate-500 dark:text-slate-400 mb-8">
          Digital & Sustainable Transformation Expert
        </p>

        {/* Contact Links */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          <a
            href="mailto:prasad.sgsits@gmail.com"
            className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-lg font-semibold hover:bg-emerald-700 transition-colors shadow-sm hover:shadow-md"
          >
            <Mail size={18} />
            Email Me
          </a>
          <a
            href="https://linkedin.com/in/prasadtilloo"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-lg font-semibold hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
          >
            <Linkedin size={18} />
            LinkedIn
          </a>
          <a
            href="https://github.com/prasadt1"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-lg font-semibold hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
          >
            <Github size={18} />
            GitHub
          </a>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          {[
            { value: '15+', label: 'Years Experience' },
            { value: '$1M+', label: 'Cost Savings' },
            { value: '8', label: 'Industries' },
            { value: '99.99%', label: 'SLA Achieved' }
          ].map((metric, idx) => (
            <div key={idx} className="p-6 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-800">
              <div className="text-3xl font-bold text-emerald-600 dark:text-emerald-400 mb-1 font-serif">{metric.value}</div>
              <div className="text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide">{metric.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-12 items-start">
        {/* Main Content (Left) */}
        <div>
          {/* Professional Summary */}
          <section className="mb-16">
            <h2 className="text-3xl font-serif font-bold text-slate-900 dark:text-white mb-8 flex items-center gap-3">
              <span className="w-8 h-1 bg-emerald-500 rounded-full"></span>
              About Me
            </h2>
            <div className="prose prose-lg text-slate-600 dark:text-slate-300 max-w-none">
              <p className="mb-6">
                Results-driven, hands-on <strong>Senior Architect & Engineering Leader</strong> with over 15 years of cross-industry expertise spanning banking, telecom, e-commerce, retail, healthcare, and AdTech. I've consistently delivered transformative results through cloud-first digital transformation and AI-driven automation across Azure and AWS.
              </p>
              <p className="mb-6">
                My work has led to <strong>30% faster deployments</strong>, significant cost efficiency improvements, and over <strong>$1M in cost savings</strong>. I specialize in designing and implementing enterprise-scale systems that handle millions of transactions daily while maintaining strict SLA compliance.
              </p>
              <p>
                Basically based in Frankfurt, Germany, I combine technical depth with strategic vision, ensuring compliance with global standards (GDPR, HIPAA, ISO 27001) while fostering high-performance engineering cultures.
              </p>
            </div>
          </section>

          {/* Experience Timeline */}
          <section className="mb-16">
            <h2 className="text-3xl font-serif font-bold text-slate-900 dark:text-white mb-10 flex items-center gap-3">
              <Briefcase className="text-emerald-600 dark:text-emerald-500" size={28} />
              Career Journey
            </h2>

            <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-3 space-y-12 pb-4">
              {experiences.map((exp, idx) => (
                <div key={idx} className="relative pl-8 md:pl-12">
                  <div className="absolute -left-[9px] top-6 w-4 h-4 rounded-full bg-white dark:bg-slate-900 border-4 border-emerald-500 shadow-sm" />

                  <div className="group bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 hover:shadow-md transition-all">
                    <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between mb-2">
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white">{exp.company}</h3>
                      <span className="text-sm font-medium text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800 px-3 py-1 rounded-full">{exp.period}</span>
                    </div>

                    <div className="text-lg text-emerald-700 dark:text-emerald-400 font-semibold mb-2">{exp.role}</div>
                    <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400 mb-4">
                      <MapPin size={14} />
                      {exp.location}
                    </div>

                    <ul className="space-y-2">
                      {exp.achievements.map((item, i) => (
                        <li key={i} className="flex items-start gap-2.5 text-slate-600 dark:text-slate-300">
                          <ChevronRight size={16} className="text-emerald-500 mt-1 shrink-0" />
                          <span className="leading-relaxed">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Certifications & Education (Grid) */}
          <section className="mb-16">
            <h2 className="text-3xl font-serif font-bold text-slate-900 dark:text-white mb-8 flex items-center gap-3">
              <Award className="text-emerald-600 dark:text-emerald-500" size={28} />
              Certifications & Education
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
                <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                  <Target size={20} className="text-blue-600 dark:text-blue-400" />
                  Top Certifications
                </h3>
                <ul className="space-y-4">
                  {certifications.map((cert, idx) => (
                    <li key={idx} className="flex items-start justify-between border-b border-slate-200 dark:border-slate-700 last:border-0 pb-3 last:pb-0">
                      <div>
                        <div className="font-semibold text-slate-900 dark:text-white">{cert.title}</div>
                        <div className="text-sm text-slate-500 dark:text-slate-400">{cert.issuer}</div>
                      </div>
                      <span className="text-xs font-medium text-slate-400 dark:text-slate-500 bg-white dark:bg-slate-900 px-2 py-1 rounded border border-slate-200 dark:border-slate-700">
                        {cert.date}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-6">
                {/* Education */}
                <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                    <GraduationCap size={20} className="text-purple-600 dark:text-purple-400" />
                    Education
                  </h3>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">Bachelor of Engineering (B.E.)</div>
                    <div className="text-emerald-600 dark:text-emerald-400 font-medium">Computer Science</div>
                    <div className="text-sm text-slate-500 dark:text-slate-400 mt-1">S.G.S.I.T.S, India</div>
                  </div>
                </div>

                {/* Languages */}
                <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                    <Languages size={20} className="text-amber-600 dark:text-amber-500" />
                    Languages
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-slate-700 dark:text-slate-300">English</span>
                      <span className="text-xs font-semibold bg-emerald-100 dark:bg-emerald-900/50 text-emerald-800 dark:text-emerald-300 px-2 py-0.5 rounded">C2 Native</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-slate-700 dark:text-slate-300">German</span>
                      <span className="text-xs font-semibold bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-300 px-2 py-0.5 rounded">B1 Intermediate</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* Sidebar (Right) */}
        <aside className="hidden lg:block lg:sticky lg:top-24 lg:h-[calc(100vh-8rem)] lg:overflow-y-auto space-y-8 pr-2">
          <QuickStats />

          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <h3 className="font-serif font-bold text-xl text-slate-900 dark:text-white mb-6 pb-2 border-b border-slate-100 dark:border-slate-700">
              Tech Stack
            </h3>
            <TechChips categories={techCategories} />
          </div>

          <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-lg relative overflow-hidden ring-1 ring-slate-800">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <Zap size={100} />
            </div>
            <h3 className="font-bold text-xl mb-4 relative z-10">Leadership Philosophy</h3>
            <ul className="space-y-4 relative z-10">
              {[
                { icon: <Target size={18} />, text: "Strategic Alignment" },
                { icon: <Heart size={18} />, text: "Empathetic Leadership" },
                { icon: <BookOpen size={18} />, text: "Continuous Learning" }
              ].map((item, idx) => (
                <li key={idx} className="flex items-center gap-3 text-slate-300">
                  <span className="text-emerald-400">{item.icon}</span>
                  {item.text}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <Recommendations mode="scroll" />
          </div>
        </aside>
      </div>

      {/* Footer CTA */}
      <div className="mt-20 p-12 bg-slate-900 rounded-3xl text-center text-white relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6 text-white">
            Let's Build Something Together
          </h2>
          <p className="text-lg text-slate-400 mb-8 max-w-2xl mx-auto">
            Open to freelance, contract, and full-time opportunities in cloud architecture, AI/ML implementation, and enterprise modernization.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 px-8 py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold transition-all hover:-translate-y-1"
          >
            Get in Touch
            <ChevronRight size={20} />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;