import React from 'react';
import { Linkedin, Github, ExternalLink } from 'lucide-react';

const ContactPage: React.FC = () => {
  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const name = (form.elements.namedItem('name') as HTMLInputElement).value;
    const email = (form.elements.namedItem('email') as HTMLInputElement).value;
    const message = (form.elements.namedItem('message') as HTMLTextAreaElement).value;

    // For now: open mail client using mailto (no backend configured)
    const subject = encodeURIComponent(`Portfolio contact from ${name}`);
    const body = encodeURIComponent(`${message}\n\nContact: ${email}`);
    window.location.href = `mailto:prasad.sgsits@gmail.com?subject=${subject}&body=${body}`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 dark:text-white mb-8">Contact</h1>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-12">
        <div>
          <p className="text-lg text-slate-600 dark:text-slate-300 mb-8">
            I'm open to freelance, contract, and full-time opportunities. Use the form to send a message or email me directly.
          </p>

          <form onSubmit={onSubmit} className="space-y-4">
            <input
              name="name"
              placeholder="Your name"
              required
              className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 focus:ring-2 focus:ring-emerald-500 focus:outline-none transition-shadow"
            />
            <input
              name="email"
              type="email"
              placeholder="Your email"
              required
              className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 focus:ring-2 focus:ring-emerald-500 focus:outline-none transition-shadow"
            />
            <textarea
              name="message"
              placeholder="How can I help?"
              required
              rows={6}
              className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 focus:ring-2 focus:ring-emerald-500 focus:outline-none transition-shadow resize-y"
            />
            <div className="flex gap-4">
              <button
                type="submit"
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold transition-colors shadow-sm"
              >
                Send message
              </button>
              <a
                href="mailto:prasad.sgsits@gmail.com"
                className="px-6 py-3 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg font-semibold transition-colors shadow-sm"
              >
                Email
              </a>
            </div>
          </form>

          <div className="mt-16">
            <h3 className="text-xl font-serif font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
              Other ways to connect
              <div className="h-px bg-slate-200 dark:bg-slate-700 flex-1 ml-4"></div>
            </h3>
            <div className="flex gap-6">
              <a
                href="https://linkedin.com/in/prasadtilloo"
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col items-center gap-3 p-6 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-xl hover:border-blue-200 dark:hover:border-blue-900 hover:-translate-y-1 transition-all duration-300 min-w-[140px]"
              >
                <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Linkedin size={24} />
                </div>
                <span className="font-semibold text-slate-700 dark:text-slate-200 group-hover:text-blue-700 dark:group-hover:text-blue-400">LinkedIn</span>
                <ExternalLink size={14} className="text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
              </a>

              <a
                href="https://github.com/prasadt1"
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col items-center gap-3 p-6 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-xl hover:border-slate-300 dark:hover:border-slate-600 hover:-translate-y-1 transition-all duration-300 min-w-[140px]"
              >
                <div className="w-12 h-12 bg-slate-50 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Github size={24} />
                </div>
                <span className="font-semibold text-slate-700 dark:text-slate-200 group-hover:text-slate-900 dark:group-hover:text-white">GitHub</span>
                <ExternalLink size={14} className="text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
              </a>
            </div>
          </div>
        </div>

        <aside>
          {/* Chat assistant removed per revert */}
        </aside>
      </div>
    </div>
  );
};

export default ContactPage;
