
import { GoogleGenerativeAI } from '@google/generative-ai';
import { SYSTEM_PROMPT } from './aiContext';

const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
const genAI = new GoogleGenerativeAI(apiKey || '');
const model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash-exp' });

export interface ChatMessage {
    role: 'user' | 'model';
    content: string;
}

export const chatWithPrasad = async (history: ChatMessage[], message: string): Promise<string> => {
    if (!apiKey) {
        throw new Error('Gemini API key not configured');
    }

    try {
        const chat = model.startChat({
            history: [
                {
                    role: 'user',
                    parts: [{ text: SYSTEM_PROMPT }]
                },
                {
                    role: 'model',
                    parts: [{ text: "Understood. I am Prasad's Digital Agent. I'm ready to answer questions about his experience and skills." }]
                },
                ...history.map(msg => ({
                    role: msg.role === 'user' ? 'user' : 'model',
                    parts: [{ text: msg.content }]
                } as any)) // Cast to any to avoid strict type issues with simple history mapping
            ],
            generationConfig: {
                maxOutputTokens: 500,
            }
        });

        const result = await chat.sendMessage(message);
        const response = await result.response;
        return response.text();
    } catch (error) {
        console.error('Chat Service Error:', error);
        throw new Error('Failed to get response from AI agent.');
    }
};
