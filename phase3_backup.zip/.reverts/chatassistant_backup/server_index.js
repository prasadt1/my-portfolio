// Backup of server/index.js (removed from main source tree)
// Original server implementation provided a simple RAG scaffold with /api/query, /api/upsert, /api/reindex
export const backup = true;
