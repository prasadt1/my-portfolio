Backup: server README prior to removal
