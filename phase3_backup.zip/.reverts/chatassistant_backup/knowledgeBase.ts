// Backup of knowledgeBase.ts (removed from main source tree)
export const KNOWLEDGE_BASE_BACKUP = [];
